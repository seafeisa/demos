

#import <UIKit/UIKit.h>

@interface myCell : UITableViewCell
@property (nonatomic, strong) UILabel *lab;

- (void)loadData:(id)obj;
@end
