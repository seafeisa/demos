

#import <UIKit/UIKit.h>

@interface secondCell : UITableViewCell
@property (nonatomic, strong) UILabel *lab;

- (void)loadData:(id)obj;
@end
